#include <stdlib.h>
#include <sys/time.h>

#define	COMMON_SEED		3

extern	char	*random_word(void);
extern	long	microseconds(void);

